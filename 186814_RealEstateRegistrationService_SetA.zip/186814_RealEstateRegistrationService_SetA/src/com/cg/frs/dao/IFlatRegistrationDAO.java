package com.cg.frs.dao;

import java.util.ArrayList;

import com.cg.frs.dto.RegistrationDetails;

public interface IFlatRegistrationDAO {

	void registerFlat(RegistrationDetails rd);

	int getAllOwnerIds(int ownerID);

	ArrayList<Integer> getAllOwnerids();

}
