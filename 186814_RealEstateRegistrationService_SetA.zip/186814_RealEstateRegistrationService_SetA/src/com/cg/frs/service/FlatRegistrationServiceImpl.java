package com.cg.frs.service;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.dao.IFlatRegistrationDAO;
import com.cg.frs.dto.RegistrationDetails;

public class FlatRegistrationServiceImpl implements IFlatRegistrationService {
	Scanner sc=new Scanner(System.in);
	IFlatRegistrationDAO fd=new FlatRegistrationDAOImpl();// creating an object for calling the dao class

	public void registerFlat(RegistrationDetails rd) {
		fd.registerFlat(rd);// passing the values to dao class
	}
	@Override
	public int getAllOwnerIds(int ownerID) {
		return fd.getAllOwnerIds(ownerID);// passing the values to dao class
		
	}

	public int validationOwnerID(int ownerID)//validating the owner id whether it is equal or not
	{
		while(true)
			{
				if(ownerID<1||ownerID>3)
				{
					System.out.println("owner does not exists");
					System.out.println("Enter the owner id again: ");
					ownerID=sc.nextInt();
				}
				else
				{
					return ownerID;
				}
		}		
	}
	
	public int validationFlatType(int flatType)//validating the flat type whether it is equal or not
	{
		while(true)
			{
				if(flatType<1||flatType>2)
				{
					System.out.println("flat type does not exists");
					System.out.println("Enter the flat type again: ");
					flatType=sc.nextInt();
				}
				else
				{
					return flatType;
				}
		}		
	}
	
	public double validationSquareFeet(double sq_ft)//validating the square feet whether it is greater than zero or not
	{
		while(true)
			{
				if(sq_ft<=0)
				{
					System.out.println("Square feet should not be less than zero");
					System.out.println("Enter the flat type again: ");
					sq_ft=sc.nextInt();
				}
				else
				{
					return sq_ft;
				}
		}		
	}
	
	public long validationRentAmount(long rentAmt)//validating the rent amount whether it is greater than zero  or not
	{
		while(true)
			{
				if(rentAmt<=0)
				{
					System.out.println("Rent amount should not be less than zero");
					System.out.println("Enter the rent amount again: ");
					rentAmt=sc.nextInt();
				}
				else
				{
					return rentAmt;
				}
		}		
	}
	
	public long validationDepositAmount(long depositAmt,long rentAmt)//validating the deposit amount whether it is greater than rent amount or not
	{
		while(true)
			{
				if(depositAmt<rentAmt)
				{
					System.out.println("Deposit amount should be lesser than rent amount");
					System.out.println("Enter the deposit amount again: ");
					depositAmt=sc.nextInt();
				}
				else
				{
					return depositAmt;
				}
		}		
	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() {
		return fd.getAllOwnerids();
	}

	
}
