package com.cg.frs.dao;

import java.util.HashMap;

import com.cg.frs.dto.FlatOwner;
import com.cg.frs.dto.RegistrationDetails;

public class FlatRegistrationDAOImpl implements IFlatRegistrationDAO {
	FlatOwner fo=new FlatOwner();
	RegistrationDetails rd=new RegistrationDetails();
	private static HashMap<Integer,FlatOwner> owners=new HashMap<Integer,FlatOwner>();
	
	static HashMap<Integer,RegistrationDetails> flatDetails=new HashMap<Integer,RegistrationDetails>();
	
	static
	{
		owners.put(1,new FlatOwner(1,"Vaishali","9023002122"));//storing the given details into hashmap
		owners.put(2,new FlatOwner(2,"Megha","9643221234"));
		owners.put(3,new FlatOwner(3,"Manish","5453221234"));
	}
	
	public void addDetails(FlatOwner fo)
	{
		this.fo=fo;
		owners.put(fo.getOwnerID(),fo);
		System.out.println(owners);
	}
	
	public static HashMap<Integer, FlatOwner> owners() {// return the HashMap values
		
		return owners;
	}

	public static HashMap<Integer,RegistrationDetails> flatDetails()
	{
		return flatDetails;
	}


	@Override
	public void registerFlat(RegistrationDetails rd) {// register the details whom register the flats in this estate
		flatDetails.put(rd.getOwnerID(),rd);
		rd=(RegistrationDetails)flatDetails.get(rd.getOwnerID());
	}

	@Override
	public void showDetails(int ownerID) {
		rd=(RegistrationDetails)flatDetails.get(ownerID);
	/*	double sq_ft=rd.getSq_ft();
		long rentAmt=rd.getRentAmt();
		long depositAmt=rd.getDepositAmt();
		int flatType=rd.getFlatType();*/
		
		/*System.out.println("Flat type : "+rd.getFlatType());
		System.out.println("Square feet : "+rd.getSq_ft());
		System.out.println("Rent amount : "+rd.getRentAmt());
		System.out.println("Deposited amount : "+rd.getDepositAmt());*/
	}

}
